import { NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";

const projectSchema = z.object({
  title: z.string().trim().min(2).max(160),
  description: z.string().trim().max(3000).default(""),
  category: z.string().trim().max(100).default("Logo Design"),
  image_url: z.union([z.string().trim().url().max(2000), z.literal("")]).optional(),
  is_published: z.boolean().default(false),
});
const updateSchema = projectSchema.extend({ id: z.string().uuid() });
const deleteSchema = z.object({ id: z.string().uuid() });

async function authorized() {
  const { user, isAdmin } = await requireAdmin();
  return Boolean(user && isAdmin);
}

export async function POST(request: Request) {
  if (!(await authorized())) return NextResponse.json({ message: "Administrator access required." }, { status: 403 });
  const parsed = projectSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Please check the project details." }, { status: 400 });
  const admin = createAdminClient();
  const { data, error } = await admin.from("projects").insert({
    ...parsed.data,
    image_url: parsed.data.image_url || null,
  }).select("id").single();
  if (error) return NextResponse.json({ message: "Could not create project." }, { status: 500 });
  return NextResponse.json({ message: "Project created.", id: data.id });
}

export async function PATCH(request: Request) {
  if (!(await authorized())) return NextResponse.json({ message: "Administrator access required." }, { status: 403 });
  const parsed = updateSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Please check the project details." }, { status: 400 });
  const { id, ...values } = parsed.data;
  const admin = createAdminClient();
  const { error } = await admin.from("projects").update({ ...values, image_url: values.image_url || null }).eq("id", id);
  if (error) return NextResponse.json({ message: "Could not update project." }, { status: 500 });
  return NextResponse.json({ message: "Project updated." });
}

export async function DELETE(request: Request) {
  if (!(await authorized())) return NextResponse.json({ message: "Administrator access required." }, { status: 403 });
  const parsed = deleteSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Invalid project." }, { status: 400 });
  const admin = createAdminClient();
  const { error } = await admin.from("projects").delete().eq("id", parsed.data.id);
  if (error) return NextResponse.json({ message: "Could not delete project." }, { status: 500 });
  return NextResponse.json({ message: "Project deleted." });
}
