import { NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";

const bodySchema = z.object({ status: z.enum(["approved", "rejected", "revoked"]) });

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const { user, isAdmin } = await requireAdmin();
  if (!user || !isAdmin) return NextResponse.json({ message: "Administrator access required." }, { status: 403 });

  const { id } = await context.params;
  const parsed = bodySchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Invalid request status." }, { status: 400 });

  const admin = createAdminClient();
  const { data: cardRequest, error: readError } = await admin.from("card_requests")
    .select("id,user_id,card_type,status,email").eq("id", id).maybeSingle();
  if (readError) return NextResponse.json({ message: "Could not load this request." }, { status: 500 });
  if (!cardRequest) return NextResponse.json({ message: "Request not found." }, { status: 404 });
  if (!cardRequest.user_id) return NextResponse.json({ message: "This request is not linked to a user account. Ask the applicant to submit it again while signed in." }, { status: 409 });

  const nextStatus = parsed.data.status;
  const { error: updateError } = await admin.from("card_requests").update({ status: nextStatus }).eq("id", id);
  if (updateError) return NextResponse.json({ message: "Could not update the request." }, { status: 500 });

  if (cardRequest.card_type === "royal") {
    let roleError: { message: string } | null = null;
    if (nextStatus === "approved") {
      const { error } = await admin.from("admin_users").upsert({ user_id: cardRequest.user_id }, { onConflict: "user_id" });
      roleError = error;
    } else {
      const { error } = await admin.from("admin_users").delete().eq("user_id", cardRequest.user_id);
      roleError = error;
    }
    if (roleError) {
      await admin.from("card_requests").update({ status: cardRequest.status }).eq("id", id);
      return NextResponse.json({ message: nextStatus === "approved" ? "Could not grant administrator access." : "Could not revoke administrator access." }, { status: 500 });
    }
  }

  await admin.from("admin_notifications").insert({
    kind: "card_decision",
    title: `${cardRequest.card_type} card ${nextStatus}`,
    body: `Access request for ${cardRequest.email} was ${nextStatus}.`,
  });
  return NextResponse.json({ message: `Request ${nextStatus}.` });
}
