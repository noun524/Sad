import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "TN-Naun Designer | Logo & Graphic Designer",
  description: "Creative work that moves people. Professional logo design and graphic design portfolio.",
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "https://tn-naun-designer.com")
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}