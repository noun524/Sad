import Link from "next/link";
import CardRequestForm from "@/components/CardRequestForm";

export default function CardAccess() {
  return <main className="page"><div className="container">
    <span className="eyebrow">Private membership</span>
    <h1 className="page-title">Card Access Request</h1>
    <p className="lead">Sign in or create an account first, then submit your details. Royal Card access requires administrator approval and grants administrator privileges. Gold Card access requires the shared password and administrator approval; it does not grant dashboard control.</p>
    <p className="muted">Already have an account? <Link className="pink" href="/auth">Sign in here</Link>.</p>
    <div className="section"><CardRequestForm /></div>
  </div></main>;
}
