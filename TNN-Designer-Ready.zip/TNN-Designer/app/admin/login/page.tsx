import AuthForm from "@/components/AuthForm";

export default function AdminLogin() {
  return <main className="page"><div className="container">
    <span className="eyebrow">Restricted area</span>
    <h1 className="page-title">Administrator Sign In</h1>
    <p className="lead">Sign in with the account approved for administrator access.</p>
    <div className="section"><AuthForm redirectTo="/admin" /></div>
  </div></main>;
}
