import Link from "next/link";
import { redirect } from "next/navigation";
import { requireAdmin } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import SignOut from "@/components/SignOut";
import AdminPushNotifications from "@/components/AdminPushNotifications";
import AdminCardRequestActions from "@/components/AdminCardRequestActions";
import AdminProjectManager from "@/components/AdminProjectManager";

export const dynamic = "force-dynamic";

export default async function Admin() {
  const { user, isAdmin } = await requireAdmin();
  if (!user) redirect("/admin/login");
  if (!isAdmin) redirect("/");

  const supabase = createAdminClient();
  const [messages, requests, projects, notifications] = await Promise.all([
    supabase.from("messages").select("*").order("created_at", { ascending: false }).limit(50),
    supabase.from("card_requests").select("*").order("created_at", { ascending: false }).limit(50),
    supabase.from("projects").select("*").order("created_at", { ascending: false }),
    supabase.from("admin_notifications").select("*").order("created_at", { ascending: false }).limit(20),
  ]);

  return <main className="page"><div className="container">
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
      <div><span className="eyebrow">Private control center</span><h1 className="page-title">Admin Dashboard</h1><p className="muted">Signed in as {user.email}</p></div>
      <SignOut />
    </div>
    <div className="section"><AdminPushNotifications /></div>
    <div className="admin-layout section">
      <aside className="admin-side">
        <a href="#overview">Overview</a><a href="#messages">Client Inbox</a><a href="#cards">Card Requests</a><a href="#projects">Portfolio Projects</a><a href="#alerts">Notifications</a><Link href="/portfolio">View public site ↗</Link>
      </aside>
      <div>
        <section id="overview" className="grid" style={{ gridTemplateColumns: "repeat(3,minmax(0,1fr))" }}>
          <div className="card"><span className="muted">Messages</span><h2>{messages.data?.length || 0}</h2></div>
          <div className="card"><span className="muted">Card requests</span><h2>{requests.data?.length || 0}</h2></div>
          <div className="card"><span className="muted">Projects</span><h2>{projects.data?.length || 0}</h2></div>
        </section>

        <section id="messages" className="section card"><h2>Client Inbox</h2>
          <div className="table-wrap"><table className="table"><thead><tr><th>From</th><th>Message</th><th>Date</th><th>Reply</th></tr></thead><tbody>
            {messages.data?.length ? messages.data.map((item) => <tr key={item.id}>
              <td>{item.name}<br /><span className="muted">{item.email}</span></td>
              <td style={{ whiteSpace: "normal", minWidth: 220 }}>{item.message}</td>
              <td>{new Date(item.created_at).toLocaleDateString()}</td>
              <td><a className="pink" href={`mailto:${item.email}?subject=Re:%20Your%20message`}>Reply ↗</a></td>
            </tr>) : <tr><td colSpan={4}>No messages yet.</td></tr>}
          </tbody></table></div>
        </section>

        <section id="cards" className="section card"><h2>Card Access Requests</h2>
          <div className="table-wrap"><table className="table"><thead><tr><th>Applicant</th><th>Card</th><th>Status</th><th>Requested</th><th>Decision</th></tr></thead><tbody>
            {requests.data?.length ? requests.data.map((item) => <tr key={item.id}>
              <td>{item.full_name}<br /><span className="muted">{item.email}{item.phone ? ` · ${item.phone}` : ""}</span></td>
              <td className={item.card_type === "royal" ? "pink" : "gold"}>{item.card_type}</td>
              <td>{item.status}</td>
              <td>{new Date(item.created_at).toLocaleDateString()}</td>
              <td><AdminCardRequestActions id={item.id} status={item.status} /></td>
            </tr>) : <tr><td colSpan={5}>No card requests yet.</td></tr>}
          </tbody></table></div>
          <p className="muted">Approving a Royal Card grants this account administrator privileges. Approving a Gold Card grants access to the private Gold Card portal only.</p>
        </section>

        <section id="projects" className="section"><h2>Portfolio Projects</h2>
          <p className="muted">Create, edit, publish or delete portfolio entries. Images can currently be added with a hosted image URL.</p>
          <div className="section"><AdminProjectManager initialProjects={projects.data || []} /></div>
        </section>

        <section id="alerts" className="section card"><h2>Important Notifications</h2>
          {notifications.data?.length ? notifications.data.map((item) => <p key={item.id}><strong>{item.title}</strong><br /><span className="muted">{item.body}</span></p>) : <p className="muted">No notifications yet.</p>}
        </section>
      </div>
    </div>
  </div></main>;
}
